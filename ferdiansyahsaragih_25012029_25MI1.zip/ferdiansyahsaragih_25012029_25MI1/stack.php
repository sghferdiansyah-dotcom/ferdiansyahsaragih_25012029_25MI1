<?php
session_start();
if (!isset($_SESSION['stack_data'])) $_SESSION['stack_data'] = ['Data 1', 'Data 2'];

if (isset($_POST['push'])) {
    $data = trim($_POST['data'] ?? '');
    if ($data !== '') $_SESSION['stack_data'][] = $data;
}
if (isset($_POST['pop']) && count($_SESSION['stack_data']) > 0) array_pop($_SESSION['stack_data']);
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stack</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<h1>Implementasi Stack</h1>
<p>Stack menggunakan prinsip <b>LIFO</b> — Last In, First Out.</p>
<form method="post" class="form"><input type="text" name="data" placeholder="Masukkan data..." required><button name="push">Push</button><button name="pop" class="danger">Pop</button></form>
<div class="stack">
<?php if (!$_SESSION['stack_data']): ?><p>Stack kosong.</p>
<?php else: foreach (array_reverse($_SESSION['stack_data']) as $i => $item): ?>
<div class="stack-item"><?= htmlspecialchars($item) ?> <?= $i === 0 ? '<b>← TOP</b>' : '' ?></div>
<?php endforeach; endif; ?>
</div>
<p class="info">Push = menambahkan data ke TOP. Pop = mengambil data dari TOP.</p>
<a class="back" href="index.php">← Kembali</a>
</div></body></html>
