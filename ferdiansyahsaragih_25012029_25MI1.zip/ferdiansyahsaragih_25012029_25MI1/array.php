<?php
session_start();
if (!isset($_SESSION['array_data'])) $_SESSION['array_data'] = ['PHP', 'HTML', 'CSS'];

if (isset($_POST['add'])) {
    $data = trim($_POST['data'] ?? '');
    if ($data !== '') $_SESSION['array_data'][] = $data;
}
if (isset($_POST['delete'])) {
    $index = (int)($_POST['index'] ?? -1);
    if (isset($_SESSION['array_data'][$index])) array_splice($_SESSION['array_data'], $index, 1);
}
$dataArray = $_SESSION['array_data'];
?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Array</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<h1>Implementasi Array</h1>
<p>Array menyimpan data menggunakan indeks. Coba tambahkan atau hapus data.</p>
<form method="post" class="form">
<input type="text" name="data" placeholder="Masukkan data..." required>
<button name="add">Tambah Data</button>
</form>
<div class="data-list">
<?php foreach ($dataArray as $i => $item): ?>
<div class="item"><span><b>Index <?= $i ?></b> → <?= htmlspecialchars($item) ?></span>
<form method="post"><input type="hidden" name="index" value="<?= $i ?>"><button class="danger" name="delete">Hapus</button></form></div>
<?php endforeach; ?>
</div>
<a class="back" href="index.php">← Kembali</a>
</div></body></html>
