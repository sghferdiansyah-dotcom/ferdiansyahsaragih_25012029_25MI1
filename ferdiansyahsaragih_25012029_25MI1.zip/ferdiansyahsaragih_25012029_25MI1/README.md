# ferdiansyahsaragih_25012029_25MI1

Project PHP Struktur Data Linear: Array, Linked List, dan Stack.

## Identitas
- Nama: Ferdiansyah Saragih
- NIM: 25012029
- Kelas: 25MI1

## Menjalankan
1. Simpan folder di `htdocs` XAMPP.
2. Jalankan Apache.
3. Buka `http://localhost/ferdiansyahsaragih_25012029_25MI1/`.

## Halaman
- `index.php` - menu utama
- `array.php` - Array interaktif
- `linkedlist.php` - Linked List interaktif
- `stack.php` - Stack interaktif
