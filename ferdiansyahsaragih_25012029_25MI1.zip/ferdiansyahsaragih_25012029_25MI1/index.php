<?php
$title = "Struktur Data Linear";
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="hero">
        <h1>Project Struktur Data Linear</h1>
        <p>Implementasi PHP: Array, Linked List, dan Stack</p>
        <small>Ferdiansyah Saragih • 25012029 • 25MI1</small>
    </div>
    <div class="cards">
        <a class="card" href="array.php"><h2>Array</h2><p>Data disimpan dan diakses berdasarkan indeks.</p></a>
        <a class="card" href="linkedlist.php"><h2>Linked List</h2><p>Data tersusun dalam node yang saling terhubung.</p></a>
        <a class="card" href="stack.php"><h2>Stack</h2><p>Menggunakan konsep LIFO: Last In, First Out.</p></a>
    </div>
</div>
</body>
</html>
