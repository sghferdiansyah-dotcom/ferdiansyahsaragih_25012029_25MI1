<?php
class Node {
    public string $data;
    public ?Node $next = null;
    public function __construct(string $data) { $this->data = $data; }
}
class LinkedList {
    public ?Node $head = null;
    public function add(string $data): void {
        $newNode = new Node($data);
        if ($this->head === null) { $this->head = $newNode; return; }
        $current = $this->head;
        while ($current->next !== null) $current = $current->next;
        $current->next = $newNode;
    }
    public function delete(string $data): void {
        if ($this->head === null) return;
        if ($this->head->data === $data) { $this->head = $this->head->next; return; }
        $current = $this->head;
        while ($current->next !== null && $current->next->data !== $data) $current = $current->next;
        if ($current->next !== null) $current->next = $current->next->next;
    }
}
session_start();
if (!isset($_SESSION['linked'])) $_SESSION['linked'] = ['Node A', 'Node B', 'Node C'];
if (isset($_POST['add'])) {
    $value = trim($_POST['data'] ?? '');
    if ($value !== '') $_SESSION['linked'][] = $value;
}
if (isset($_POST['delete'])) {
    $value = $_POST['value'] ?? '';
    $pos = array_search($value, $_SESSION['linked'], true);
    if ($pos !== false) array_splice($_SESSION['linked'], $pos, 1);
}
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Linked List</title><link rel="stylesheet" href="style.css"></head>
<body><div class="container">
<h1>Implementasi Linked List</h1>
<p>Setiap node menyimpan data dan terhubung ke node berikutnya.</p>
<form method="post" class="form"><input type="text" name="data" placeholder="Masukkan node..." required><button name="add">Tambah Node</button></form>
<div class="nodes">
<?php foreach ($_SESSION['linked'] as $i => $item): ?>
<div class="node"><b>Node <?= $i + 1 ?></b><br><?= htmlspecialchars($item) ?><br><span class="arrow">↓ next</span>
<form method="post"><input type="hidden" name="value" value="<?= htmlspecialchars($item) ?>"><button class="danger" name="delete">Hapus Node</button></form></div>
<?php endforeach; ?>
</div>
<a class="back" href="index.php">← Kembali</a>
</div></body></html>
